package trivera.storage;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;	

class IntegerArrayTest {

	@BeforeAll
	public static void log() {
		System.out.println("Exercise: GenericDynamicArray - IntegerArrayTest");
		System.out.println("Type: solution-code");
		System.out.println("Java: " + System.getProperty("java.version"));
	}

	//CODE8:Implement Tests to test ObjectArray<Integer> array

}
